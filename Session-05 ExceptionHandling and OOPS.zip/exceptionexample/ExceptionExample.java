package exceptionexample;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class ExceptionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		int num,div,out;
		
		System.out.println("enter num");
		num = sc.nextInt();
		
		System.out.println("enter num");
		div = sc.nextInt();
		
		try {
			
			if(div<0) {
				ArithmeticException error = new ArithmeticException("Divisor cannot be less than 0");
				throw error; //throw is just like go to Exception block
			}
			//div
			out = num/div;
			System.out.println("output is "+out);
		
		}
		catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println(e);
		}		
		catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}finally {
			System.out.println("end of block");
		}
		//add
		out = num+div;
		System.out.println("sum of two numebrs "+out);
		
	}

}
