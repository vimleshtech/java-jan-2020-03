package exceptionexample;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowsExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		FileReader fr =new FileReader("C:\\Users\\vkumar15\\Desktop\\Agend.docx");
	
		System.out.println("ok");
	}

}
