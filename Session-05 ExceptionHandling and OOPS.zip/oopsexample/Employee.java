package oopsexample;

import java.util.Scanner;

public class Employee {

	//data members 
	int eid;
	int salary;
	String  name;
	
	//methods 
	void newEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter eid ");
		eid = sc.nextInt();
		
		System.out.println("enter salary ");
		salary= sc.nextInt();
		
		System.out.println("enter name ");
		name= sc.next();
		
	}
	void show() {
		System.out.println("------Employee Details---------");
		System.out.println("eid is "+eid);
		System.out.println("name is "+name);
		System.out.println("salary is "+salary);
		
	}
	
	
}

