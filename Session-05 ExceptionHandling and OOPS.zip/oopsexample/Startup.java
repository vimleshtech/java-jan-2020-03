package oopsexample;

public class Startup {

	public static void main(String[] args) {
	
		//create object
		Employee e1 = new Employee();
		Employee e2 = new Employee();
		
		e1.newEmployee();
		e2.newEmployee();
		
		
		e2.show();
		e1.show();

	}

}
