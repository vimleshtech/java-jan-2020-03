package testcases;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.util.Properties;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestClass {

	static Properties prop =null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		try {
			
			//read .properties file 
			FileInputStream fs = new FileInputStream("C:\\Users\\vkumar15\\Documents\\Training\\Eclipse_Workspace\\Code2\\src\\objects\\objects.properties");
			
			prop =new Properties();
			prop.load(fs); //convert byte code to key value
			
		}catch (Exception e) {
			// TODO: handle exception
		}
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		
		/*
		 * WebDriver driver = ..
		 * driver.get(url)
		 * driver.findElementI()
		 */
		
		//driver.get(url)
		String u = prop.getProperty("url");		
		//driver.get(u)
		System.out.println(u);
		
		String n = prop.getProperty("name");
		System.out.println(n);
				
	}

}
