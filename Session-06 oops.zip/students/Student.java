package students;

public class Student {

	//non-static 
	private int sid;
	
	//static data member 
	private static String name;
	
	final int age=18;
	
	
	
	public void newStudent(int sid, String sname, int age) {
		
		if(age<this.age) {
			System.out.println("age should be greater than 18");
			
		}	
		else {
			this.sid = sid;
			this.name = sname;
		}
			
	}
	public  void show() {
		System.out.println("sid  "+this.sid);
		System.out.println("name  "+this.name);
	}
	
	public static void test() {
		System.out.println("test function ");
	}
}
