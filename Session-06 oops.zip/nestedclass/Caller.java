package nestedclass;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent p = new Parent();
		p.inParent();
		
		Parent.Tax.y=1;
		Parent.Tax.test();
		
		
		//static class object
		Parent.GST obj = p.new  GST();
		obj.x=11;
		obj.y =44;
		obj.hello();
		
		

	}

}
