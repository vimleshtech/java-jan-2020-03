package nestedclass;

//final can be use with class 
//but static parent class cannot declare in java 
public  class Parent {
	
	//inner class be static 
	public static class Tax{
		
		public int x;
		public  static int y;  //static declartion is allowed only in static inner class 
		public  static void test() {
			
			System.out.println("hello - in tax "+y);
		}
		public  void test2() {
			
			System.out.println("hello - in tax "+y);
		}
		
	}
	
	public  class GST{
		public int x;
		public  int y;
		public  void hello() {
			System.out.println("hello- in GST");
		}
		
	}
	
	public void inParent() {
		System.out.println("in parent ");
	}
}
