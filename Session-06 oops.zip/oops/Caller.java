package oops;

import javax.rmi.CORBA.Stub;

import students.Student;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create an object
		//Employee e = new Employee();
		//e.newEmployee();
		//e.show();
		
		//call to function
		Student s1 = new Student();
		Student s2 = new Student();
		
		s1.newStudent(11, "Nitin Sharma",22);
		s1.show(); 
		s2.newStudent(22, "Raman",20);
		
		
		s1.show(); //Raman
		s2.show(); //Raman 
		
		
		Student.test();
		
		

	}

}

