package oops;

import java.util.Scanner;

public class Employee {

	//data member
	private int eid; //default is public for same package
	private String name;
	private  int sal;
	
	//method or function 
	protected void newEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter eid , name , and salary");
		eid = sc.nextInt();
		name = sc.next();
		sal = sc.nextInt();		
	}
	public void show() {
		
		System.out.println("---------- student details --------- ");
		System.out.println("eid ="+eid+" name ="+name+" sal="+sal);
	}
	
}
