package polymorphism;

public class AdvanceCalculator extends Cal {

	void welcome() {
		System.out.println("in child class");
	}
	void add(double a, double b) {
		System.out.println(a+b);
	}
	void add(double a, double b, double c) {
		System.out.println(a+b+c);
	}
	
	void add(double a, double b, double c, double d) {
		System.out.println(a+b+c+d);
	}
	
	void sub(double a, double b) {
		System.out.println(a-b);
	}
	
	
	
}
