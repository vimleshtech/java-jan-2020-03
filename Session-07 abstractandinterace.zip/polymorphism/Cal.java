package polymorphism;

public class Cal {

	
	void welcome() {
		System.out.println("in parent class");
	}
	void add(int a, int b) {
		System.out.println(a+b);
	}
	void add(int a, int b, int c) {
		System.out.println(a+b+c);
	}
	
	void add(int a, int b, int c, int d) {
		System.out.println(a+b+c+d);
	}
	
}
