package polymorphism;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AdvanceCalculator ac = new AdvanceCalculator();
		ac.add(11.22, 1);
		ac.add(11.22, 33.45);
		ac.add(11.22, 11);
		ac.add(11, 11,43,6);
		
		
		Cal c = new Cal();
		c.welcome();
		
		
		AdvanceCalculator a = new AdvanceCalculator();
		a.welcome();
		
		//overriding
		c =a;
		c.welcome(); //child method
	}

}
