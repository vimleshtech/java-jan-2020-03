package oops2;

public class RoadTax extends Tax {

	
}
