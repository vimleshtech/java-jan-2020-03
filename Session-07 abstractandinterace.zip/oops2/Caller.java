package oops2;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Tax o1 = new Tax();
		o1.computeTax(1000);
		
		//with argument
		Tax o2 = new Tax("us");
		o2.computeTax(1000);
		
		
		
		//copy the previous pecentage
		Tax o3 = new Tax(o2);
		o2.computeTax(1000);
		
		//
		Tax o4 = new Tax("india","mp");
		o4.computeTax(1000);
		
		
		
	}

}
