package oops2;

public class GST  extends Tax{

	
	public void realStateTax(int cost) {
		
		double t = cost*super.taxper;
		double total= t+cost;
		System.out.println("total tax on House amount "+total);
		
	}


	public void educationTax(int fee) {
		
		double t = fee*super.taxper;
		double total= t+fee;
		if(t>1000) {
			t =1000;
		}
		else {
			t -= t/2;
		}
		
		total -=t; 
		System.out.println("tax on education fee "+total);
		
	}
}

