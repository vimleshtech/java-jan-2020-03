package oops2;


public class Tax {

	double taxper;
	
	//override the default constructor
	Tax(){
		
		System.out.println("in constructor, memory is allocated");
		taxper= .10;
		
	}
	
	
	//with argument
	Tax(String country){
		System.out.println("in constructor, for country "+country);
		
		if(country.equals("india"))
			taxper =.18;
		else if(country.equals("us"))
			taxper =.28;
		else if(country.equals("uk"))
			taxper =.39;
		else
			taxper =.20;
				
	}
	
	Tax(String country, String state){
		if(country.equals("india") && state.equals("delhi"))
			taxper =.25;
		else if(country.equals("india") && state.equals("mp"))
			taxper =.05;
			
	}
	//copy from previous object
	Tax(Tax t){
		this.taxper = t.taxper; //copy the previous object tax perc for new object
	}
		
	///Method: to calculate the tax
	void computeTax(int amt) {
		double t = amt*taxper;
		double total=t+amt;
		
		System.out.println("total amt is "+total);
		
	}
	
	
	
	
}
