package oops2;

public class Caller2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GST c = new GST();
		c.educationTax(120000);
		
	}

}
