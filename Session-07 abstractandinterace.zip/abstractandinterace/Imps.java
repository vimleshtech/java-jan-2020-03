package abstractandinterace;

public class Imps extends Abs  implements Ia, Ib {

	@Override //annotation 
	void sub(int a, int b) {
		// TODO Auto-generated method stub

		System.out.println(a-b);
	}

	@Override
	void mul(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a*b);
	}

	@Override
	public void add1(int a, int b, int c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add1(int a, int b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sub1(int a, int b) {
		// TODO Auto-generated method stub
		
	}

	
}
