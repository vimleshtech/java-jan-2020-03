package abstractandinterace;

public interface Ia {

	void add1(int a, int b);
	void sub1(int a, int b);
	
}
