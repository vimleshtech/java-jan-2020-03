package abstractandinterace;

public abstract class Abs {

	void add(int a, int b) {
		System.out.println(a+b);
	}
	
	abstract void sub(int a, int b);
	abstract void mul(int a, int b);
	
}

