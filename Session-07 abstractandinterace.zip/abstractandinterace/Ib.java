package abstractandinterace;

public interface Ib {

	void add1(int a, int b, int c);
	
}
