package abstractandinterace;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Imps i = new Imps();
		i.add(11, 2);
		i.sub(11, 2);
		
	}

}
