package functionexample;
import java.util.Scanner;

public class Calculator {

	public static void main(String[] arg) {
		
		welcome();
		welcome();
		add(11,33);
		add(1541,133);
		
		int o = sub(121,4);
		System.out.println(o);
		
		int n1,n2;
		n1 = getNumber();
		n2= getNumber();
		add(n1,n2);

		int f = fact(5);
		System.out.println(f);
		
	}
	
	//no argument no return 
	static void welcome() {
		
		System.out.println("this is my first function code , we are leanring java");
		System.out.println("this class contais following functions i. welcome ii. add iii. sub iv. mul ...");
	}
	
	//no argument with return 
	static int getNumber() {
		Scanner sc = new Scanner(System.in);
		int num;
		System.out.println("enter number ");
		num = sc.nextInt();
		return num;		
	}
	//argument with no return 
	static void add(int a, int b) {
		int c = a+b;
		System.out.println("sum of two values "+c);
	}
	
	//argument with return 
	static int sub(int a, int b) {
		int c = a-b;
		return c;
	}
	//recussive
	static int fact(int n) {
		if (n==1)
			return n;
		else
			return n* fact(n-1);
		
	}
}
