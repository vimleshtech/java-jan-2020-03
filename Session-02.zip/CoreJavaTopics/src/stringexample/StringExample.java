package stringexample;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] arg) {
		
		Scanner  s = new Scanner(System.in);
		String str,nstr;
		
		System.out.println("enter string ");
		str = s.nextLine(); //read string from console
		
		System.out.println("you have entered : "+str);
		
		//to upper case 
		System.out.println("in upper case : "+str.toUpperCase());
		//to lower case
		System.out.println("in lower case : "+str.toLowerCase());
		//replace
		System.out.println("in lower case : "+str.replace("a", "xy"));
		//length 
		System.out.println("length "+str.length());
		//indexof
		System.out.println("index of m "+str.indexOf("m"));
		//charAt  
		System.out.println("char at 2 "+str.charAt(2));
		//convert to ascii code
		int n = str.charAt(2);
		System.out.println("ascii code of m "+n);
		
		//split
		String words[] = str.split(" ");
		System.out.println("workd count "+ words.length);
		System.out.println("first word "+words[0]); 
		System.out.println("second word "+words[1]);
		
		//loop 
		for(String w: words) {
			System.out.println(w);
		}
		
		
		//substring
		System.out.println("sub string "+str.substring(2,6));
		
		//concat 
		nstr = str.concat("India");
		System.out.println(nstr);
		
		nstr = str+"India";
		System.out.println(nstr);
		
		//conditional function 
		if(str.startsWith("raman")) {
			System.out.println("name start with raman");
		}
		else {
			System.out.println("not starting with raman");
		}
		
		if(str.endsWith("sinha")) {
			
			System.out.println("name end with sinha");
		}
		
		if(str.contains("ma")) {
			
			System.out.println("ma is present");
		}
		
		
		if(str.equals("raman sinha")) {
			
			System.out.println("raman sinha match");
		}
		
		
		if(str.equalsIgnoreCase("RAMAN sinha")) {
			
			System.out.println("raman sinha match with case insensetive");
		}
		
		
		
	}
}

	