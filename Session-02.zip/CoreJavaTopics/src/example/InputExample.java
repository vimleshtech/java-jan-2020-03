package example;

//Scanner is a class 
import java.util.Scanner;

public class InputExample {

	public static void main(String[] args) {

		//Create object of Scanner class 
		Scanner s  = new Scanner(System.in);
		int a,b,c;
		
		System.out.println("enter data");
		a = s.nextInt(); //nextInt() is function which read data from user
		
		System.out.println("enter data");
		b = s.nextInt(); //nextInt() is function which read data from user
		
		//addition 
		c = a+b;
		
		System.out.println("sum of two valeus "+c);
		

	}

}
