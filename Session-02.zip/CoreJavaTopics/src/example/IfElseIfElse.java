package example;

import java.util.Scanner;

public class IfElseIfElse {

	public static void main(String[] args) {
		
		
		Scanner s =new Scanner(System.in);
		int a,b,c;
		
		System.out.println("enter data ");
		a =s.nextInt();
		
		System.out.println("enter data ");
		b =s.nextInt();
		
		System.out.println("enter data ");
		c =s.nextInt();
		
		//show greater number
		if(a>b && a>c) {
			System.out.println("a is greater");
		}
		else if(b>a && b>c) {
			System.out.println("b is greater");
		}
		else {
			System.out.println("c is greater");
		}

	}

}
