package fileexample;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.SocketTimeoutException;

public class FileQuestion {

	public static void main(String[] args) throws IOException {
		
		FileReader fr = new FileReader("C:\\Users\\vkumar15\\Desktop\\mydata.txt");
		//System.out.println(fr); //print or show object(memory address) of file
		
		BufferedReader br = new BufferedReader(fr);

		String data = br.readLine(); //read first line
		//get row count
		//get word count
		//find the word or match the word
		int wc=0;
		int rc=0;
		
		
		while(data!=null) {
			
			rc++; //rc=rc+1; //row count	
			
			//word count
			String words[]= data.split(" "); //break by space
			wc+=words.length;  //13 //["Test","1:","this"]
			
			//find given word : is 
			if(data.contains("are")) {
				System.out.println("is is found");
			}
			
			data = br.readLine();
		}
		
		System.out.println("row count "+rc);
		System.out.println("word count "+wc);
	}

}

