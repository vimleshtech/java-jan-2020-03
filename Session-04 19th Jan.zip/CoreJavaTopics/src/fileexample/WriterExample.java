package fileexample;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class WriterExample {

	public static void main(String[] args) throws IOException {
		
		//,true : open in append mode 
		//false : overwrite data , default is false  
		
		FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\newfile.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		
		bw.write("hey, this is first file writing program ...");
		bw.newLine();
		bw.append("end of file");
		bw.newLine();
		bw.close();
		fw.close();
		
		System.out.println("data is saved ");
		
		
		
		
	}

}
