package fileexample;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileExample {

	public static void main(String[] args) throws IOException {

		
		FileReader fr = new FileReader("C:\\Users\\vkumar15\\Desktop\\mydata.txt");
		//System.out.println(fr); //print or show object(memory address) of file
		
		BufferedReader br = new BufferedReader(fr);
		
		String data = br.readLine(); //read first line 
		//System.out.println(data); //print first line from file
		
		//data = br.readLine();
		//System.out.println(data);
		//loop : is iterator (repeation of code)
		while(data!=null) {
			
			System.out.println(data);
			data = br.readLine();
		}

		br.close();
		fr.close();
	}

}
