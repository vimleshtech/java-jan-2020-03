package example;

import java.sql.DriverManager;	//load or register the driver 
import java.sql.Connection;	//establish the connection 
import java.sql.Statement;  //run the sql statement 
import java.util.Scanner;

import javax.xml.transform.sax.SAXTransformerFactory;

import com.mysql.jdbc.Driver;

import java.sql.PreparedStatement; //run the sql statement
import java.sql.ResultSet; //get sql result and store the variable 
import java.sql.SQLException;

public class Test {

	
	public static void saveData(int id, String name) throws SQLException, ClassNotFoundException {
		
		 
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost/javacon","root","root");
		
		//execute sql code 
		PreparedStatement ps = c.prepareStatement("insert into users(uid,name) values(?,?)");
		ps.setInt(1, id);
		ps.setString(2, name);
		int r =ps.executeUpdate(); //insert, update, delete 
		
		System.out.println(r+" rows inserted");
		c.close();
		
		
	
	}
	public static void showData() throws ClassNotFoundException, SQLException {
		
		//establish the connection 
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost/javacon","root","root");
		
		//execute sql code 
		Statement st = c.createStatement();
		ResultSet rs =  st.executeQuery("select * from users;"); //select
		
		
		//iterate data 
		while(rs.next()) {
			System.out.println(rs.getString(1)+"\t"+rs.getString(2));
			
		}
		c.close();
	}
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int i;
		String n;
		System.out.println("enter id and name");
		i = sc.nextInt();
		n =sc.next();
		
		saveData(i,n);
		showData();
	}

}
